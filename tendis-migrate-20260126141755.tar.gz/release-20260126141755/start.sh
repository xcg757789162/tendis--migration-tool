#!/bin/bash
cd "$(dirname "$0")"
mkdir -p logs
pkill -f simple-server 2>/dev/null || true
sleep 1
nohup ./simple-server > logs/stdout.log 2>&1 &
echo "服务已启动: http://localhost:8088"
echo "日志页面: http://localhost:8088/logs"
