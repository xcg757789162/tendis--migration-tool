#!/bin/bash
pkill -f simple-server && echo "服务已停止" || echo "服务未运行"
