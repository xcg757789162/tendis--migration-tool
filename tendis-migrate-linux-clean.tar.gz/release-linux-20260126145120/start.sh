#!/bin/bash
cd "$(dirname "$0")"
mkdir -p logs
pkill -f simple-server 2>/dev/null || true
sleep 1
nohup ./simple-server > logs/stdout.log 2>&1 &
sleep 2
if pgrep -f simple-server > /dev/null; then
    IP=$(hostname -I 2>/dev/null | awk '{print $1}' || echo "localhost")
    echo "=========================================="
    echo "服务已启动!"
    echo "=========================================="
    echo "访问地址: http://${IP}:8088"
    echo "日志页面: http://${IP}:8088/logs"
    echo "查看日志: tail -f logs/stdout.log"
    echo "停止服务: ./stop.sh"
    echo "=========================================="
else
    echo "启动失败，查看日志: cat logs/stdout.log"
fi
